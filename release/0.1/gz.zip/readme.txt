To use this software, you'll need the following:
	An NTSC N64 with OoT 1.0 and an Expansion Pak
	A Gameshark with a functional parallel port (note that some 3.3s only have dummy ports)
	A Parallel to USB adapter cable with bidirectional communication support
		The Gameshark utility is designed to function with a Moschip MCS7705 cable.
		Others might work but the utility will probably have to be modified.

Usage instructions
	Boot the Gameshark with a cart that works with the default keycode.
	In the Key Codes submenu, change the keycode to the one named Zelda, power off and reboot with the OoT cart.
	In the Select Cheat Codes menu, navigate to Ocarina of Time 1.0 and activate the (M) code, and only that one.
	In the Start Game submenu, toggle the Code Generator option to ON, and select Start Game With Selected Codes.
	Wait for the title screen to appear, then connect the Gameshark to your computer with your Parallel to USB adapter cable.
	Start Zadig on your computer and select the Gameshark in from the list (probably named USB Device or something similar).
	Select libusbK in the driver list and click Replace Driver.
	Close Zadig, and run the upload.bat script. This will instruct the Gameshark utility to upload the binary to the N64 RAM,
	and then disconnect the Gameshark. The operation will take a little while.
	When the utility is done uploading, you can disconnect the USB cable and start playing.

The source code for the N64 binary and Gameshark utility can be found at github.com/glankk
